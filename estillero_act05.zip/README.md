# Student Profile Form (Flutter)

A single-screen Flutter app with a student profiling form: Full Name, Age,
Gender, Address, Contact Number, and Email, with validation, a Submit button
that displays the entered info, and a Clear/Reset button.

## Files

```
student_profile_form/
├── pubspec.yaml
├── lib/
│   └── main.dart
└── README.md
```

This is just the `lib/` and config part of a Flutter project — it is missing
the platform folders (`android/`, `ios/`, `web/`, etc.) that `flutter create`
normally generates, because those are large, boilerplate, and
platform-specific. You'll generate them in step 2 below.

## 1. Install prerequisites (skip anything you already have)

- **Flutter SDK:** [docs.flutter.dev/get-started/install](https://docs.flutter.dev/get-started/install)
- **VS Code:** [code.visualstudio.com](https://code.visualstudio.com)
- **VS Code extensions:** install **Flutter** (this pulls in the Dart
  extension automatically) from the Extensions panel.
- Run `flutter doctor` in a terminal and fix anything it flags with a ✗
  (usually Android Studio / an Android license, or Xcode on macOS).

## 2. Create the project and drop these files in

The easiest path is to let Flutter generate a fresh project, then replace its
default files with these:

```bash
flutter create student_profile_form
cd student_profile_form
```

Now replace the generated `pubspec.yaml` and `lib/main.dart` with the two
files from this folder (overwrite them), keeping the `android/`, `ios/`,
`web/`, etc. folders that `flutter create` already made.

## 3. Get packages and run

In VS Code:
1. Open the `student_profile_form` folder (**File → Open Folder**).
2. Open a terminal (**Terminal → New Terminal**) and run:
   ```bash
   flutter pub get
   ```
3. At the bottom right of VS Code, click the device selector and pick a
   target — **Chrome** is the fastest way to test with no emulator setup,
   or pick a connected Android/iOS device or emulator if you have one.
4. Press **F5** (or **Run → Start Debugging**), or run `flutter run` in the
   terminal.

## 4. Test it

- Leave fields empty and tap **Submit** — each field should show a red
  validation message, and nothing should be submitted.
- Enter letters in **Age**, an invalid address for **Email**, or a too-short
  **Contact Number** — each should show its own error message.
- Fill in everything correctly and tap **Submit** — a "Submitted Profile"
  card appears below the form showing exactly what you entered, and a
  snackbar confirms the submission.
- Tap **Clear** — all fields empty out, the gender dropdown resets, any
  validation messages disappear, and the submitted card disappears.

## Notes on how it works

- `GlobalKey<FormState>` + one `TextEditingController` per field is the
  standard Flutter pattern for forms: the key lets you call `validate()` and
  `reset()` on the whole form at once, and the controllers let you read and
  clear each field's text.
- Each `TextFormField`/`DropdownButtonFormField` has its own `validator`
  function. `Form.validate()` runs all of them and returns `false` if any
  field fails, which is how the required-field and format checks work.
- `_submittedData` is a `Map<String, String>` that only gets set after a
  successful validation, and is rendered as the "Submitted Profile" card.
  Setting it back to `null` in `_clearForm` hides the card again.
