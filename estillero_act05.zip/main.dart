import 'package:flutter/material.dart';

void main() {
  runApp(const StudentProfileApp());
}

class StudentProfileApp extends StatelessWidget {
  const StudentProfileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Profile Form',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF2F6F4F),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          filled: true,
        ),
      ),
      home: const StudentProfileFormPage(),
    );
  }
}

class StudentProfileFormPage extends StatefulWidget {
  const StudentProfileFormPage({super.key});

  @override
  State<StudentProfileFormPage> createState() =>
      _StudentProfileFormPageState();
}

class _StudentProfileFormPageState extends State<StudentProfileFormPage> {
  // Key used to validate and reset the Form widget below.
  final _formKey = GlobalKey<FormState>();

  // One controller per text field so we can read and clear their values.
  // Pre-filled with sample data so the form has something to show right away.
  final _nameController = TextEditingController(text: 'Ralph James Estillero');
  final _ageController = TextEditingController(text: '20');
  final _addressController =
      TextEditingController(text: 'Carriedo, Gubat, Sorsogon');
  final _contactController = TextEditingController(text: '09977788331');
  final _emailController =
      TextEditingController(text: 'ralphjamesestillero@thelewiscollege.edu.ph');

  // Gender is a dropdown, not a text field, so it needs its own state.
  String? _selectedGender = 'Male';
  static const List<String> _genderOptions = ['Male', 'Female', 'Other'];

  // Holds the values shown in the "Submitted Profile" card.
  // Null until the user successfully submits the form at least once.
  Map<String, String>? _submittedData;

  @override
  void dispose() {
    // Always dispose controllers to avoid memory leaks.
    _nameController.dispose();
    _ageController.dispose();
    _addressController.dispose();
    _contactController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  void _submitForm() {
    // validate() runs every TextFormField's validator and the Dropdown's.
    // It returns false if any of them return an error message.
    final isValid = _formKey.currentState!.validate();
    if (!isValid) return;

    setState(() {
      _submittedData = {
        'Full Name': _nameController.text.trim(),
        'Age': _ageController.text.trim(),
        'Gender': _selectedGender!,
        'Address': _addressController.text.trim(),
        'Contact Number': _contactController.text.trim(),
        'Email': _emailController.text.trim(),
      };
    });

    FocusScope.of(context).unfocus(); // dismiss the keyboard
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Profile submitted successfully.')),
    );
  }

  void _clearForm() {
    _formKey.currentState!.reset(); // clears validation error messages
    _nameController.clear();
    _ageController.clear();
    _addressController.clear();
    _contactController.clear();
    _emailController.clear();

    setState(() {
      _selectedGender = null;
      _submittedData = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Profile Form')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Fill in the student details below.',
                  style: TextStyle(fontSize: 15, color: Colors.black54),
                ),
                const SizedBox(height: 20),

                TextFormField(
                  controller: _nameController,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    labelText: 'Full Name',
                    hintText: 'e.g. Juan Dela Cruz',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Full name is required';
                    }
                    if (value.trim().length < 2) {
                      return 'Name is too short';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _ageController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Age',
                    hintText: 'e.g. 20',
                    prefixIcon: Icon(Icons.cake_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Age is required';
                    }
                    final age = int.tryParse(value.trim());
                    if (age == null) {
                      return 'Enter a valid whole number';
                    }
                    if (age < 1 || age > 120) {
                      return 'Enter a realistic age';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  value: _selectedGender,
                  decoration: const InputDecoration(
                    labelText: 'Gender',
                    prefixIcon: Icon(Icons.wc_outlined),
                  ),
                  items: _genderOptions
                      .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                      .toList(),
                  onChanged: (value) {
                    setState(() => _selectedGender = value);
                  },
                  validator: (value) {
                    if (value == null) return 'Please select a gender';
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _addressController,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Address',
                    hintText: 'House/Street, Barangay, City',
                    prefixIcon: Icon(Icons.home_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Address is required';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _contactController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Contact Number',
                    hintText: 'e.g. 09171234567',
                    prefixIcon: Icon(Icons.phone_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Contact number is required';
                    }
                    final digitsOnly = value.replaceAll(RegExp(r'[^0-9]'), '');
                    if (digitsOnly.length < 7 || digitsOnly.length > 13) {
                      return 'Enter a valid contact number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    hintText: 'e.g. juan.delacruz@example.com',
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Email is required';
                    }
                    final emailPattern = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$');
                    if (!emailPattern.hasMatch(value.trim())) {
                      return 'Enter a valid email address';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),

                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _submitForm,
                        icon: const Icon(Icons.check_circle_outline),
                        label: const Text('Submit'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _clearForm,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Clear'),
                      ),
                    ),
                  ],
                ),

                if (_submittedData != null) ...[
                  const SizedBox(height: 28),
                  _SubmittedProfileCard(data: _submittedData!),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Displays the submitted form values in a read-only card.
class _SubmittedProfileCard extends StatelessWidget {
  final Map<String, String> data;

  const _SubmittedProfileCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.badge_outlined,
                    color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                const Text(
                  'Submitted Profile',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const Divider(height: 24),
            ...data.entries.map(
              (entry) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 140,
                      child: Text(
                        entry.key,
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                    Expanded(child: Text(entry.value)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
